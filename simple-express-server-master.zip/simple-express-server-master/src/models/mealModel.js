const meals = [
  { name: "MilkShake", type: "breakfast", price: 8 },
  { name: "Lazanya", type: "lunch", price: 20 }
];

exports.getMeals = () => {
  return meals;
};
